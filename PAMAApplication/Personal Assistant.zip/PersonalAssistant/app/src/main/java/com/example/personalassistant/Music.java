package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Music extends AppCompatActivity implements View.OnClickListener {

    private Button play, pause;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        play = findViewById(R.id.play);
        pause = findViewById(R.id.pause);

        mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.audio);

        play.setOnClickListener(this);
        pause.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if (id==R.id.play){
            mediaPlayer.start();
        }else {
            mediaPlayer.stop();
        }
    }
}