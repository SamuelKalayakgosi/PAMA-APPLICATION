package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private CardView Profile, Phone, Message, Browser, Music, Email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Profile = findViewById(R.id.Profile);
        Phone = findViewById(R.id.Phone);
        Message = findViewById(R.id.Message);
        Browser = findViewById(R.id.Browser);
        Music = findViewById(R.id.Music);
        Email = findViewById(R.id.Email);

        Profile.setOnClickListener(this);
        Phone.setOnClickListener(this);
        Message.setOnClickListener(this);
        Browser.setOnClickListener(this);
        Music.setOnClickListener(this);
        Email.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id==R.id.Profile){
            startActivity(new Intent(getApplicationContext(), profile.class));
        }else if(id==R.id.Phone){
            startActivity(new Intent(getApplicationContext(),phone.class));
        }else if(id==R.id.Music){
            startActivity(new Intent(getApplicationContext(), Music.class));
        }else if(id==R.id.Message){
            startActivity(new Intent(getApplicationContext(), sms.class));
        }else if(id==R.id.Browser){
            startActivity(new Intent(getApplicationContext(), browser.class));
        }else {
            startActivity(new Intent(getApplicationContext(), email.class));
        }
    }
}