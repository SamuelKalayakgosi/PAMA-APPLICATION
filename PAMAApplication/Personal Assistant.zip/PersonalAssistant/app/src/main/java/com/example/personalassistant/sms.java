package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sms extends AppCompatActivity {

    private EditText etRecipient, etMessage;
    private Button btSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        etRecipient = findViewById(R.id.et_recipient);
        etMessage = findViewById(R.id.et_smessage);
        btSend = findViewById(R.id.btSend);

        btSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipient = etRecipient.getText().toString().trim();
                String message = etMessage.getText().toString().trim();


                if (!recipient.equals("") && !message.equals("")) {

                    //initializing sms manager
                    SmsManager smsManager = SmsManager.getDefault();

                    //sending message
                    smsManager.sendTextMessage(recipient, null, message,
                            null, null);
                    Toast.makeText(getApplicationContext(),
                            "Sms sent successfully!", Toast.LENGTH_LONG).show();
                } else {
                    //when values are blank a toast message is displayed
                    Toast.makeText(getApplicationContext(),
                            "Enter values first", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

}