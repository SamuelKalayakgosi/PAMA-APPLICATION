package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class phone extends AppCompatActivity {

    private EditText editText1;
    private ImageButton imgButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone);

        editText1 = findViewById(R.id.et_phone);
        imgButton = findViewById(R.id.btCall);


        imgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = editText1.getText().toString();

                if(number.trim().length()>0){
                    String dial = "tel:" + number;
                    startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
                }else{
                    Toast.makeText(getApplicationContext(),"Enter Phone NUmber", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}