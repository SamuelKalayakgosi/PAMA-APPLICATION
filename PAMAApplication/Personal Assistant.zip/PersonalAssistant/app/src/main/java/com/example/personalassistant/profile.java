package com.example.personalassistant;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class profile extends AppCompatActivity {

    private TextView tv1, tv2;
    private Button btn1;
    private AlertDialog.Builder alert;
    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String NAME = "text";
    public static final String CNUMBER = "cNumber";
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tv1 = findViewById(R.id.tvName);
        tv2 = findViewById(R.id.tvNumber);
        btn1 = findViewById(R.id.editPro);
        alert = new AlertDialog.Builder(this);
        sharedPreferences = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
    }
}